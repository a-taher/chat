<?php
    session_start();
    // clear session
    session_unset();
    session_destroy();
    // redirect to index page
    header('Location: ../../index.php');
    exit();