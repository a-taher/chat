<?php


?>

<!DOCTYPE html>
<html lang="ar">
    <head>
        <!-- meta code -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <meta name="description" content="">
        <meta name="keywords" content="">

        
        <!-- css files -->
        <link rel="stylesheet" type="text/css" href="<?php echo $font; ?>css/font-awesome.min.css" >
        <link rel="stylesheet" type="text/css" href="<?php echo $css; ?>bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $css; ?>bootstrap-rtl.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $css; ?>style.css">
        <link rel="icon"   type="image/png" href="">
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Josefin+Sans" rel="stylesheet">
    </head>
    <body>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12 logo">
                    <a href="index.php">
                        <img src="<?php echo $image; ?>/logo.png" class="img-responsive center-block">
                    </a>
                </div>
            </div>    
        </div>  <!-- end header -->     
 
        <!-- end search template -->
