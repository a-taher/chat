<?php
/** ----------
 * Created by ahmed taher.
 * site: eshtery bblash.
 * description: connect to database.
 --------------*/

    $dsn = "mysql:host=localhost;dbname=chat";
    $user = "root";
    $password = "";
    $option = array(
        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8',
    );

    try {
        $con = new PDO($dsn,$user,$password,$option);
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    catch (PDOException $e) {
        echo "failed to connect database " . $e->getMessage();
    }


