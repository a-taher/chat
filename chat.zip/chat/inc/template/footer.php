
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-12 footer text-center">
					<p> تصميم وبرمجه <a href="http://facebook.com/xzcmido">Ahmed Taher</a> </p>
				</div>
			</div>
		</div>
	
        <script type="text/javascript" src="<?php echo $js; ?>html5shiv.min.js"></script>
        <script type="text/javascript" src="<?php echo $js; ?>jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo $js; ?>bootstrap.min.js"></script>
        <script type="text/javascript" src="<?php echo $js; ?>java.js"></script>

    </body>
</html>