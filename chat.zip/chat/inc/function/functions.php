<?php

    /* 
    * GET ALL FORM DATABASE BY ORDER 
    */
    function getall($select, $table)
    {
        global $con;
        $stmt = $con->prepare("SELECT $select FROM $table");
        $stmt->execute(array());
        $rows = $stmt->fetchAll();
        return $rows;
    }

 