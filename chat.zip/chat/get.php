<?php
    //start session
    session_start();
    ob_start();
    //include ini file
    include 'inc/template/connect.php';

    if (isset($_SESSION['username'])) {
       
        $do = $_GET['do'] ? $_GET['do'] : 'get';

        if ($do == 'send') {
            
            $username   = $_GET['user'];
            $msg        = htmlentities($_GET['msg']);

            $stmt = $con->prepare('INSERT INTO messenger (name, msg) VALUES(?,?)');
            $stmt->execute(array($username, $msg));

        } elseif($do == 'get') {

            $stmt = $con->prepare('SELECT * FROM messenger');
            $stmt->execute(array());
            $msg = $stmt->fetchAll();

            foreach ($msg as $ms) {
                
                echo '<p class="msg">'. $ms['msg'] .'</p>';
                echo '<p class="name"> تم الارسال بواسطه: '. $ms['name'] .'</p>';

            }

        }



    } else {
        header('Location: index.php');
    }

    
    ob_flush();
?>