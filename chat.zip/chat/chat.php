<?php
    //start session
    session_start();
    ob_start();
    //include ini file
    include 'ini.php';

    if (isset($_SESSION['username'])) {
       
       $username = $_SESSION['username'];

        echo '<div class="alert alert-info text-center"> اهلا بك '. $username .' لتسجيل الخروج من الشات <a href="'. $temp .'logout.php"> اضغط هنا </a> </div>';

        ?>

        <title> شات سمارت </title>

        <div class="col-md-12 chat text-center">

            <script type="text/javascript">

                setInterval(function(){ getUsers(); }, 1000);

                function getUsers()
                {
                    $.ajax({
                        url: "get.php?do=get",
                        type: 'GET',
                        success: function(data) {
                        $('#chatbox').html(data);
                        }
                    });
                }
            </script>

            <div id="chatbox">
                
            </div>
            <form id="form">
                <input type="hidden" id="name" value="<?php echo $username; ?>" />
                <input class="form-control" id="msg" placeholder="اكتب رسالتك ثم اضغط Enter" />
                <span class="btn btn-primary Enter"> Enter </span>
            </form>
            
        </div>
        <?php

        // include footer
        include $temp . 'footer.php'; 

    } else {
        header('Location: index.php');
    }

    
    ob_flush();
?>