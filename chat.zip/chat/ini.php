<?php
    //connect database file
    include 'inc/template/connect.php';

    //Routs
    $temp   = 'inc/template/';      //template directory
    $libs   = 'inc/libs/';          // liberary directory
    $lang   = 'inc/language/';      //language directory
    $func   = 'inc/function/';       // function directory
    $css    = 'theme/css/';         // css directory
    $js     = 'theme/js/';          // js directory
    $font   = 'theme/font/';        // font directory
    $image  = 'theme/image/';       // image directory
    $upload =  'upload/';           // upload file  

    // include functions file
    include $func . 'functions.php';
    // include header page
    include $temp . 'header.php';
   