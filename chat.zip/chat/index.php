<?php
    //start session
    session_start();
    ob_start();
    //include ini file
    include 'ini.php'; 

    if (isset($_SESSION['username'])) {
        
        header('Location: chat.php');

    } else {

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        $_SESSION['username'] = $_POST['username'];

        echo '<div class="alert alert-success text-center"> جارى الدخول الى الدردشه خلال 3 ثوانى </div>';

        header('Refresh: 3; url= chat.php');

    }

    ?>

    <title>دخول الشات</title>

    <div class="col-md-12 login text-center">
        <p> اهلا بكم فى شات <strong>سمارت</strong> للدخول الى الدردشه اكتب اسمك فى حقل اسم المستخدم ثم اضغط على تسجيل الدخول </p>
         <form class="form-horizontal" action="index.php" method="POST">
             <input type="text" name="username" placeholder="اسم المستخدم" class="form-control">
             <input type="submit" value="تسجيل الدخول" class="btn btn-primary">
         </form>
    </div>


    <?php

    // include footer
    include $temp . 'footer.php';

    }
    
    ob_flush();
?>