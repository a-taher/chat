$(document).ready(function () {

	$('.Enter').click(function() {

		var user = $('#name').val();
	    var msg = $('#msg').val();	

	     $.ajax({

	        type: 'GET',
	        url: 'get.php?do=send&user='+ user + '&msg='+ msg

	    });

	});

	


});